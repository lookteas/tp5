<?php
return array (
  'clearlog' => 
  array (
    0 => 'clearlog',
    1 => 86400,
    2 => 1493357981,
  ),
);
?>