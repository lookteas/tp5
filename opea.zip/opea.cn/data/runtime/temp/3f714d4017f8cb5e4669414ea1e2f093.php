<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:45:"/Data/webapp/opea.cn/addons/info/gitinfo.html";i:1491654852;}*/ ?>
<div class="widget-box sl-indextop10 text-left">
	<script src='https://git.oschina.net/rainfer/YFCMF/widget_preview'></script>
	<style>
		.pro_name a{color: #4183c4;}
		.osc_git_title{background-color: #d8e5f1;}
		.osc_git_box{background-color: #fafafa;}
		.osc_git_box{border-color: #ddd;}
		.osc_git_info{color: #666;}
		.osc_git_main a{color: #4183c4;}
	</style>
</div>